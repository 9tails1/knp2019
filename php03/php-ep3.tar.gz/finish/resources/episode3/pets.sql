TRUNCATE TABLE `pet`;

INSERT INTO `pet`
    (`id`, `name`, `breed`, `age`, `weight`, `bio`, `image`)
    VALUES
    (1, 'Chew Barka', 'Bichon', '2 years', 8, 'The park, The pool or the Playground - I love to go anywhere! I am really great at... SQUIRREL!', 'pet1.png');

INSERT INTO `pet`
    (`id`, `name`, `breed`, `age`, `weight`, `bio`, `image`)
    VALUES
    (2, 'Spark Pug', 'Pug', '1.5 years', 11, 'You want to go to the dog park in style? Then I am your pug!', 'pet2.png');

INSERT INTO `pet`
    (`id`, `name`, `breed`, `age`, `weight`, `bio`, `image`)
    VALUES
    (3, 'Pico de Gato', 'Bengal', '5 years', 9, 'Oh hai, if you do not have a can of salmon I am not interested.', 'pet3.png');

INSERT INTO `pet`
    (`id`, `name`, `breed`, `age`, `weight`, `bio`, `image`)
    VALUES
    (4, 'Pancake', 'Bulldog', '1 year', 9, 'Treats and Snoozin!', 'pancake.png');
