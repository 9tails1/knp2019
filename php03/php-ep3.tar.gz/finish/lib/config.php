<?php

$configVars = array(
    'database_dsn'  => 'mysql:dbname=air_pup;host=localhost',
    'database_user' => 'root',
    'database_pass' => null,
);

return $configVars;
